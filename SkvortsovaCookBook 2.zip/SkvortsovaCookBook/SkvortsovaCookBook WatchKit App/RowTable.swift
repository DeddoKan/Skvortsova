//
//  RowTable.swift
//  SkvortsovaCookBook WatchKit Extension
//
//  Created by Student on 01.03.2022.
//

import WatchKit

class RowTable: NSObject {

    @IBOutlet weak var rowPicture: WKInterfaceImage!
    @IBOutlet weak var rowRecipeName: WKInterfaceLabel!
}
