//
//  InterfaceController.swift
//  SkvortsovaCookBook WatchKit Extension
//
//  Created by Student on 22.02.2022.
//

import WatchKit
import Foundation



class TableRecipesIC: WKInterfaceController {

    @IBOutlet weak var teble: WKInterfaceTable!
    
    override func awake(withContext context: Any?) {
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }

}
