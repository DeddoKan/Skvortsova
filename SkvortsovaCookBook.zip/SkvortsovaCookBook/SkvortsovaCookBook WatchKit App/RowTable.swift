//
//  RowTable.swift
//  SkvortsovaCookBook
//
//  Created by Student on 22.02.2022.
//

import WatchKit

class RowTable: NSObject {
    
    @IBOutlet weak var rowPicture: WKInterfaceImage!
    @IBOutlet weak var rowRecipeName: WKInterfaceLabel!

}
